const serverURL = "http://localhost:8080"
const currencySymbol = "₹";
const appName = "RewordAI";
const stripeKey = "YOUR_STRIPE_KEY";

export { serverURL, currencySymbol, appName, stripeKey };