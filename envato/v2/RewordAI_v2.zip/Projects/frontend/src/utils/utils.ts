const serverURL = "http://localhost:8080"
const currencySymbol = "₹";
const appName = "RewordAI";
const stripeKey = "pk_test_SCTPV4fZ9kMlryTRZ6XXzgDac90D00AQLTb51NaV7yFrkiQqJuN9j1IlzllFXnYSyCU1BVYpyXxBzycVuM5jTVFKB5FauiR3c5";

export { serverURL, currencySymbol, appName, stripeKey };