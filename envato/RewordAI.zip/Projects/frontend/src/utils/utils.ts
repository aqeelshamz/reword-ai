const serverURL = "http://localhost:8080"

export default serverURL;